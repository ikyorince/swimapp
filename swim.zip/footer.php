<nav class="navbar fixed-bottom navbar-custom">
  <div class="container-fluid whitetext">
	  <a class="nav-link" href="index.php">stock</a>
	  <a class="nav-link" href="addproduct.php">Add New Product</a>
	  <a class="nav-link" href="editproduct.php">Edit a Product</a>
	  <a class="nav-link" href="sellproduct.php">make a sale</a>
	  <a class="nav-link" href="sellog.php"> Log </a>

  </div>
</nav>


</body>
  <!-- Bootstrap core JavaScript -->
  <script src="jquery/jquery.slim.min.js"></script>
  <script src="bootstrap/js/bootstrap.bundle.min.js"></script>
</html>